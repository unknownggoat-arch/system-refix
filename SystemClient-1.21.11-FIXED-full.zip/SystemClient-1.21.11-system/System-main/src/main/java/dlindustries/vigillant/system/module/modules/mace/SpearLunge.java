package dlindustries.vigillant.system.module.modules.mace;

import dlindustries.vigillant.system.event.events.TickListener;
import dlindustries.vigillant.system.mixin.MinecraftClientAccessor;
import dlindustries.vigillant.system.module.Category;
import dlindustries.vigillant.system.module.Module;
import dlindustries.vigillant.system.module.setting.BooleanSetting;
import dlindustries.vigillant.system.module.setting.KeybindSetting;
import dlindustries.vigillant.system.module.setting.ModeSetting;
import dlindustries.vigillant.system.module.setting.NumberSetting;
import dlindustries.vigillant.system.utils.EncryptedString;
import dlindustries.vigillant.system.utils.EnchantmentUtil;
import dlindustries.vigillant.system.utils.ItemSwapper;
import dlindustries.vigillant.system.utils.KeyUtils;
import dlindustries.vigillant.system.utils.SwapGuard;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;

/**
 * Press the activate key: the spear (prefers one with Lunge) is swapped into your hand, a jab is made
 * (that is what triggers Lunge) and the item you were holding is swapped back.
 */
public final class SpearLunge extends Module implements TickListener {
	private static final RegistryKey<Enchantment> LUNGE =
			RegistryKey.of(RegistryKeys.ENCHANTMENT, Identifier.of("minecraft", "lunge"));

	private final KeybindSetting activateKey = new KeybindSetting(EncryptedString.of("Activate Key"), -1, false)
			.setDescription(EncryptedString.of("Key that swaps to the spear and lunges"));
	private final ModeSetting<ItemSwapper.Mode> swapMode = new ModeSetting<>(EncryptedString.of("Swap Mode"), ItemSwapper.Mode.HandSwap, ItemSwapper.Mode.class)
			.setDescription(EncryptedString.of("Hand Swap: spear swaps places with the item in your hand (works from the inventory too). Hotbar: only selects the spear slot"));
	private final BooleanSetting preferLunge = new BooleanSetting(EncryptedString.of("Prefer Lunge"), true)
			.setDescription(EncryptedString.of("Pick a spear with the Lunge enchantment first"));
	private final BooleanSetting switchBack = new BooleanSetting(EncryptedString.of("Switch Back"), true)
			.setDescription(EncryptedString.of("Put your old item back after the lunge"));
	private final NumberSetting switchDelay = new NumberSetting(EncryptedString.of("Switch Delay"), 0, 10, 2, 1)
			.setDescription(EncryptedString.of("Ticks to wait after the jab before switching back"));
	private final BooleanSetting holdRepeat = new BooleanSetting(EncryptedString.of("Hold Repeat"), false)
			.setDescription(EncryptedString.of("Keep lunging while the key is held"));
	private final NumberSetting repeatDelay = new NumberSetting(EncryptedString.of("Repeat Delay"), 1, 40, 10, 1)
			.setDescription(EncryptedString.of("Ticks between lunges while Hold Repeat is on"));

	private final ItemSwapper swapper = new ItemSwapper();
	private boolean wasPressed;
	private int restoreTimer;
	private int cooldown;

	public SpearLunge() {
		super(EncryptedString.of("Spear Lunge"),
				EncryptedString.of("Swaps to your spear on a key, lunges and swaps back"),
				-1,
				Category.mace);
		addSettings(activateKey, swapMode, preferLunge, switchBack, switchDelay, holdRepeat, repeatDelay);
	}

	@Override
	public void onEnable() {
		eventManager.add(TickListener.class, this);
		wasPressed = false;
		restoreTimer = 0;
		cooldown = 0;
		super.onEnable();
	}

	@Override
	public void onDisable() {
		eventManager.remove(TickListener.class, this);
		swapper.restore();
		super.onDisable();
	}

	@Override
	public void onTick() {
		if (mc.player == null || mc.interactionManager == null) return;

		if (swapper.isActive()) {
			if (restoreTimer >= switchDelay.getValueInt()) {
				swapper.restore();
			} else {
				restoreTimer++;
			}
		}

		if (mc.currentScreen != null) return;

		int key = activateKey.getKey();
		boolean pressed = key >= 0 && KeyUtils.isKeyPressed(key);
		if (!pressed) {
			wasPressed = false;
			cooldown = 0;
			return;
		}

		boolean fresh = !wasPressed;
		wasPressed = true;

		if (!fresh && !holdRepeat.getValue()) return;
		if (cooldown > 0) {
			cooldown--;
			return;
		}

		if (!swapper.equip(this::spearScore, swapMode.getMode())) return;

		jab();

		if (swapper.isActive()) {
			if (switchBack.getValue()) {
				restoreTimer = 0;
			} else {
				swapper.clear();
			}
		}
		cooldown = repeatDelay.getValueInt();
	}

	/** Uses the game's own attack path, that is what performs the spear jab (and so the lunge). */
	private void jab() {
		SwapGuard.internalAttack = true;
		try {
			((MinecraftClientAccessor) mc).invokeDoAttack();
		} finally {
			SwapGuard.internalAttack = false;
		}
	}

	private int spearScore(ItemStack stack) {
		if (stack.isEmpty()) return -1;
		if (!Registries.ITEM.getId(stack.getItem()).getPath().endsWith("_spear")) return -1;
		return preferLunge.getValue() && EnchantmentUtil.hasEnchantment(stack, LUNGE) ? 2 : 1;
	}
}
